SUITS = ['♥️', '♠️', '♦️', '♣️']
VALUES = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
COLORS = ['red', 'blue', 'green', 'yellow']
NUMBER_OF_PLAYERS = 4
NUMBER_OF_TEAMS = 2
SPOTS_PER_REGION = 18
SPOTS_PER_HOUSE = 4
MOVE_DESCRIPTION = {
	'OUT' : 'Take a piece out.', 
	'MOVE' : f'Move x time(s) forward.', 
	'SWITCH' : f'Switch piece with piece of player x in spot x.', 
	'CHANGE_CARD' : 'Pick another card', 
	'BACK' : f'Move 4 spots backward.', 
	'ENTER' : f'Enter house spot number x.', 
	'SEVEN': f'Play a seven split.',
	'FIVE': f'Move an opponent\'s piece 5 times forward.',
	'HOP': 'Hop from one position numbered 7 to the next.',
	}
DEAL_CARD_COUNTS = (5, 4, 4)
